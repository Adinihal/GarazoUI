'use client';
import LoginPanel from '../components/LoginPannel';

export default function LoginRoute() {
  return <LoginPanel />;
}