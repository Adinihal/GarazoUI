(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_0766a282._.js",
  "static/chunks/src_app_c3aad58f._.js",
  "static/chunks/src_app_styles_LoginPanel_module_d449a093.css"
],
    source: "dynamic"
});
