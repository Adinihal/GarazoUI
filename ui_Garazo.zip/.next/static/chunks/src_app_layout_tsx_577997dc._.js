(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_824acb5f._.js",
  "static/chunks/[root-of-the-server]__9bd385b4._.css"
],
    source: "dynamic"
});
