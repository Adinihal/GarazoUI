(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_styles_LoginPanel_module_d449a093.css",
  "static/chunks/node_modules_next_f5074bf6._.js",
  "static/chunks/src_app_c3aad58f._.js"
],
    source: "dynamic"
});
